/*
 * Copyright (c) [2020], MediaTek Inc. All rights reserved.
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws.
 * The information contained herein is confidential and proprietary to
 * MediaTek Inc. and/or its licensors.
 * Except as otherwise provided in the applicable licensing terms with
 * MediaTek Inc. and/or its licensors, any reproduction, modification, use or
 * disclosure of MediaTek Software, and information contained herein, in whole
 * or in part, shall be strictly prohibited.
*/
/*
 ***************************************************************************
 ***************************************************************************

	Module Name:
	dot11i_wpa.h

	Revision History:
	Who			When			What
	--------		----------		----------------------------------------------

*/

#ifndef	__DOT11I_WPA_H__
#define	__DOT11I_WPA_H__

#include "rtmp_type.h"
#include "dot11_base.h"

/* The length is the EAPoL-Key frame except key data field.
   Please refer to 802.11i-2004 ,Figure 43u in p.78 */
#define MIN_LEN_OF_EAPOL_KEY_MSG	95

/* The related length of the EAPOL Key frame */
#define LEN_KEY_DESC_NONCE			32
#define LEN_KEY_DESC_IV				16
#define LEN_KEY_DESC_RSC			8
#define LEN_KEY_DESC_ID				8
#define LEN_KEY_DESC_REPLAY			8
#define LEN_KEY_DESC_MIC			16
#define LEN_KEY_DESC_MIC_SHA384			24
#define LEN_KEY_DESC_MIC_MAX			LEN_KEY_DESC_MIC_SHA384

/* EAP Code Type */
#define EAP_CODE_REQUEST	1
#define EAP_CODE_RESPONSE	2
#define EAP_CODE_SUCCESS    3
#define EAP_CODE_FAILURE    4

/* EAPOL frame Protocol Version */
#define	EAPOL_VER					1
#define	EAPOL_VER2					2

/* EAPOL-KEY Descriptor Type */
#define WPA1_KEY_DESC				0xfe
#define WPA2_KEY_DESC               0x02
#define OSEN_KEY_DESC               0x00

/* Key Descriptor Version of Key Information */
#define KEY_DESC_NOT_DEFINED		0
#define KEY_DESC_OSEN			KEY_DESC_NOT_DEFINED
#define KEY_DESC_TKIP			1
#define KEY_DESC_AES			2
#define KEY_DESC_EXT			3

#define IE_WPA					221
#define IE_RSN					48

#define WPA_KDE_TYPE			0xdd

/*EAP Packet Type */
#define	EAPPacket		0
#define	EAPOLStart		1
#define	EAPOLLogoff		2
#define	EAPOLKey		3
#define	EAPOLASFAlert	4
#define	EAPTtypeMax		5

#define PAIRWISEKEY					1
#define GROUPKEY					0

/* RSN IE Length definition */
#define MAX_LEN_OF_RSNIE			255
#define MIN_LEN_OF_RSNIE			2
#define MAX_LEN_OF_RSNXEIE                      255
#define MIN_LEN_OF_RSNXEIE                      2
#define MAX_LEN_GTK					32
#define MIN_LEN_GTK					5

#ifdef HOSTAPD_OWE_SUPPORT
#define MAX_LEN_OF_TRANS_IE			48
#endif

#define LEN_PSK						64
#define LEN_MAX_PMK					64
#define LEN_PMK_SHA512					64
#define LEN_PMK_SHA384					48
#define LEN_PMK						32
#define LEN_MAXPMK					64
#define LEN_PMKID					16
#define LEN_PMK_NAME				16

#define LEN_GMK						32

#define LEN_PTK_KCK					16
#define LEN_PTK_KEK					16
#define LEN_TK						16	/* The length Temporal key. */
#define LEN_TKIP_MIC				8	/* The length of TX/RX Mic of TKIP */
#define LEN_TK2						(2 * LEN_TKIP_MIC)
#define LEN_PTK						(LEN_PTK_KCK + LEN_PTK_KEK + LEN_TK + LEN_TK2)

#define LEN_PTK_KCK_SHA384			24
#define LEN_PTK_KEK_SHA384			32
#define LEN_TK_SHA384				32
#define LEN_PTK_SHA384				(LEN_PTK_KCK_SHA384 + LEN_PTK_KEK_SHA384 + LEN_TK_SHA384)
#define LEN_OWE_PTK_SHA384			(LEN_PTK_KCK_SHA384 + LEN_PTK_KEK_SHA384 + LEN_AES_TK)

#define LEN_TKIP_PTK				LEN_PTK
#define LEN_AES_PTK					(LEN_PTK_KCK + LEN_PTK_KEK + LEN_TK)
#define LEN_MAX_PTK					88 /* 512 bits max, KCK(24)+KEK(32)+TK(32) */
#define LEN_TKIP_GTK				(LEN_TK + LEN_TK2)
#define LEN_AES_GTK					LEN_TK
#define LEN_MAX_GTK					32
#define LEN_MAX_IGTK				32
#define LEN_MAX_BIGTK				LEN_MAX_IGTK
#define LEN_TKIP_TK					(LEN_TK + LEN_TK2)
#define LEN_AES_TK					LEN_TK
#define LEN_CCMP128_TK				16
#define LEN_CCMP256_TK				32
#define LEN_GCMP128_TK				16
#define LEN_GCMP256_TK				32
#define LEN_BIP128_IGTK				16
#define LEN_BIP256_IGTK				32

#define LEN_WEP40					5
#define LEN_WEP104					13
#define LEN_WEP128					16
#define LEN_WPI_MIC				8

#define OFFSET_OF_PTK_TK			(LEN_PTK_KCK + LEN_PTK_KEK)	/* The offset of the PTK Temporal key in PTK */
#define OFFSET_OF_TKIP_RX_MIC	(OFFSET_OF_PTK_TK + LEN_TK)
#define OFFSET_OF_TKIP_TX_MIC	(OFFSET_OF_TKIP_RX_MIC + LEN_TKIP_MIC)

#define LEN_KDE_HDR					6
#define LEN_NONCE					32
#define LEN_PN						6
#define LEN_TKIP_IV_HDR				8
#define LEN_CCMP_HDR				8
#define LEN_CCMP_MIC				8
#define LEN_OUI_SUITE				4
#define LEN_WEP_TSC					3
#define LEN_WPA_TSC					6
#define LEN_WEP_IV_HDR				4
#define LEN_ICV						4

/* It's defined in IEEE Std 802.11-2007 Table 8-4 */
typedef enum _WPA_KDE_ID {
	KDE_RESV0 = 0,
	KDE_GTK = 1,
	KDE_RESV2 = 2,
	KDE_MAC_ADDR = 3,
	KDE_PMKID = 4,
	KDE_SMK = 5,
	KDE_NONCE = 6,
	KDE_LIFETIME = 7,
	KDE_ERROR = 8,
	KDE_IGTK = 9,				/* Defined in IEEE 802.11w/D10.0 */
	KDE_KEYID = 10,
	KDE_MUL_BAND_GTK = 11,
	KDE_MUL_BAND_KEYID = 12,
	KDE_OCI = 13,
	KDE_BIGTK = 14,
	KDE_RESV_OTHER
} WPA_KDE_ID;

/* EAPOL Key Information definition within Key descriptor format */
typedef	struct GNU_PACKED _KEY_INFO {
#ifdef RT_BIG_ENDIAN
	UCHAR	KeyAck:1;
	UCHAR	Install:1;
	UCHAR	KeyIndex:2;
	UCHAR	KeyType:1;
	UCHAR	KeyDescVer:3;
	UCHAR	Rsvd:3;
	UCHAR	EKD_DL:1;		/* EKD for AP; DL for STA */
	UCHAR	Request:1;
	UCHAR	Error:1;
	UCHAR	Secure:1;
	UCHAR	KeyMic:1;
#else
	UCHAR	KeyMic:1;
	UCHAR	Secure:1;
	UCHAR	Error:1;
	UCHAR	Request:1;
	UCHAR	EKD_DL:1;       /* EKD for AP; DL for STA */
	UCHAR	Rsvd:3;
	UCHAR	KeyDescVer:3;
	UCHAR	KeyType:1;
	UCHAR	KeyIndex:2;
	UCHAR	Install:1;
	UCHAR	KeyAck:1;
#endif
}	KEY_INFO, *PKEY_INFO;

/* EAPOL Key descriptor format */
typedef	struct GNU_PACKED _KEY_DESCRIPTER {
	UCHAR		Type;
	KEY_INFO	KeyInfo;
	UCHAR		KeyLength[2];
	UCHAR		ReplayCounter[LEN_KEY_DESC_REPLAY];
	UCHAR		KeyNonce[LEN_KEY_DESC_NONCE];
	UCHAR		KeyIv[LEN_KEY_DESC_IV];
	UCHAR		KeyRsc[LEN_KEY_DESC_RSC];
	UCHAR		KeyId[LEN_KEY_DESC_ID];
	UCHAR		KeyMicAndData[0];
}	KEY_DESCRIPTER, *PKEY_DESCRIPTER;

typedef	struct GNU_PACKED _EAPOL_PACKET {
	UCHAR				ProVer;
	UCHAR				ProType;
	UCHAR				Body_Len[2];
	KEY_DESCRIPTER		KeyDesc;
}	EAPOL_PACKET, *PEAPOL_PACKET;

typedef struct GNU_PACKED _KDE_HDR {
	UCHAR               Type;
	UCHAR               Len;
	UCHAR               OUI[3];
	UCHAR               DataType;
	UCHAR				octet[0];
}   KDE_HDR, *PKDE_HDR;

/*802.11i D10 page 83 */
typedef struct GNU_PACKED _GTK_KDE {
#ifndef RT_BIG_ENDIAN
	UCHAR               Kid:2;
	UCHAR               tx:1;
	UCHAR               rsv:5;
	UCHAR               rsv1;
#else
	UCHAR               rsv:5;
	UCHAR               tx:1;
	UCHAR               Kid:2;
	UCHAR               rsv1;
#endif
	UCHAR               GTK[0];
}   GTK_KDE, *PGTK_KDE;

/* For WPA1 */
typedef struct GNU_PACKED _RSNIE {
	UCHAR   oui[4];
	USHORT  version;
	UCHAR   mcast[4];
	USHORT  ucount;
	struct GNU_PACKED {
		UCHAR oui[4];
	} ucast[1];
} RSNIE, *PRSNIE;

/* For WPA2 */
typedef struct GNU_PACKED _RSNIE2 {
	USHORT  version;
	UCHAR   mcast[4];
	USHORT  ucount;
	struct GNU_PACKED {
		UCHAR oui[4];
	} ucast[1];
} RSNIE2, *PRSNIE2;

/*Updated RSNE 802.11-2016 has only the version field as mandatory*/
typedef struct GNU_PACKED _RSNIE3 {
	USHORT  version;
} RSNIE3, *PRSNIE3;

/* AKM Suite */
typedef struct GNU_PACKED _RSNIE_AUTH {
	USHORT acount;
	struct GNU_PACKED {
		UCHAR oui[4];
	} auth[1];
} RSNIE_AUTH, *PRSNIE_AUTH;

/* PMKID List */
typedef struct GNU_PACKED _RSNIE_PMKID {
	USHORT pcount;
	struct GNU_PACKED {
		UCHAR list[16];
	} pmkid[1];
} RSNIE_PMKID, *PRSNIE_PMKID;

typedef	union GNU_PACKED _RSN_CAPABILITIES	{
	struct	GNU_PACKED {
#ifdef RT_BIG_ENDIAN
		USHORT		Rsvd2:1;
		USHORT		ocvc:1;
		USHORT		Rsvd:6;
		USHORT		MFPC:1;
		USHORT		MFPR:1;
		USHORT		GTKSA_R_Counter:2;
		USHORT		PTKSA_R_Counter:2;
		USHORT		No_Pairwise:1;
		USHORT		PreAuth:1;
#else
		USHORT		PreAuth:1;
		USHORT		No_Pairwise:1;
		USHORT		PTKSA_R_Counter:2;
		USHORT		GTKSA_R_Counter:2;
		USHORT		MFPR:1;
		USHORT		MFPC:1;
		USHORT		Rsvd:6;
		USHORT		ocvc:1;
		USHORT		Rsvd2:1;
#endif
	}	field;
	USHORT			word;
}	RSN_CAPABILITIES, *PRSN_CAPABILITIES;

typedef struct GNU_PACKED _EAP_HDR {
	UCHAR   ProVer;
	UCHAR   ProType;
	UCHAR   Body_Len[2];
	UCHAR   code;
	UCHAR   identifier;
	UCHAR   length[2]; /* including code and identifier, followed by length-2 octets of data */
} EAP_HDR, *PEAP_HDR;


#endif /* __DOT11I_WPA_H__ */

